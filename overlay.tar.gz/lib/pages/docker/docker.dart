import 'package:dsm_helper/util/container_ports.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:dsm_helper/pages/docker/detail.dart';
import 'package:dsm_helper/util/function.dart';
import 'package:dsm_helper/util/log.dart';
import 'package:dsm_helper/widgets/bubble_tab_indicator.dart';
import 'package:dsm_helper/widgets/animation_progress_bar.dart';
import 'package:dsm_helper/widgets/label.dart';
import 'package:dsm_helper/widgets/neu_back_button.dart';
import 'package:extended_text/extended_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:neumorphic/neumorphic.dart';

class Docker extends StatefulWidget {
  final String title;
  Docker({this.title: 'Docker'});
  @override
  _DockerState createState() => _DockerState();
}

class _DockerState extends State<Docker> with SingleTickerProviderStateMixin {
  TabController _tabController;
  List containers = [];
  List images = [];
  List registries = [];
  Map<String, bool> powerLoading = {};
  Map utilization;
  Map<String, List<int>> containerPorts = {};
  int portsGeneration = 0;
  bool containerLoading = true;
  bool imageLoading = true;
  @override
  void initState() {
    _tabController = TabController(length: 3, vsync: this);
    getContainer();
    getImage();
    super.initState();
  }

  getContainer() async {
    final generation = ++portsGeneration;
    var res = await Api.dockerContainerInfo();
    if (!mounted || generation != portsGeneration) return;
    setState(() {
      containerLoading = false;
    });
    if (res['success']) {
      List result = res['data']['result'];
      result.forEach((item) {
        if (item['success'] == true) {
          switch (item['api']) {
            case "SYNO.Core.System.Utilization":
              setState(() {
                utilization = item['data'];
              });
              break;
            case "SYNO.Docker.Container":
              setState(() {
                containers = item['data']['containers'];
                containers.sort((a, b) {
                  return a['name'].compareTo(b['name']);
                });
              });
              break;
            case "SYNO.Docker.Container.Resource":
              List resources = item['data']['resources'];
              resources.forEach((resource) {
                containers.forEach((container) {
                  if (resource['name'] == container['name']) {
                    setState(() {
                      container['cpu'] = resource['cpu'];
                      container['memory'] = resource['memory'];
                      container['memoryPercent'] = resource['memoryPercent'];
                    });
                  }
                });
              });
              break;
          }
        }
      });
    }
    if (res['success'] == true) {
      containerPorts.clear();
      _loadContainerPorts(List.of(containers), generation);
    }
  }

  Future<void> _loadContainerPorts(List items, int generation) async {
    var next = 0;
    Future<void> worker() async {
      while (next < items.length && mounted && generation == portsGeneration) {
        final item = items[next++];
        if (item['status'] != 'running' || item['name'] == null) continue;
        try {
          final response = await Api.dockerDetail(item['name'], 'get');
          if (!mounted || generation != portsGeneration) return;
          final data = response == null ? null : response['data'];
          final profile = data is Map ? data['profile'] : null;
          if (response != null && response['success'] == true && profile is Map) {
            final ports = webCandidatePorts(profile['port_bindings']);
            setState(() { containerPorts[item['name'].toString()] = ports; });
          }
        } catch (_) {
          // A failed detail request should not stop other containers loading.
        }
      }
    }
    await Future.wait(List.generate(items.length < 4 ? items.length : 4, (_) => worker()));
  }

  Future<void> _openContainerPort(int port, String scheme) async {
    final url = containerWebUri(Util.baseUrl, port, scheme);
    if (url == null) {
      Util.toast('无法确定 NAS 地址');
      return;
    }
    try {
      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) Util.toast('无法打开浏览器');
    } catch (_) {
      Util.toast('无法打开浏览器');
    }
  }

  getImage() async {
    var res = await Api.dockerImageInfo();
    Log.logger.info(res);
    setState(() {
      imageLoading = false;
    });
    if (res['success']) {
      List result = res['data']['result'];
      result.forEach((item) {
        if (item['success'] == true) {
          switch (item['api']) {
            case "SYNO.Docker.Image":
              setState(() {
                images = item['data']['images'];
                images.sort((a, b) {
                  return a['repository'].compareTo(b['repository']);
                });
              });
              break;
            case "SYNO.Docker.Registry":
              setState(() {
                registries = item['data']['registries'];
              });
              break;
          }
        }
      });
    }
  }

  power(container, String action, {bool preserveProfile}) async {
    if (action == "signal" || action == "delete") {
      showCupertinoModalPopup(
        context: context,
        builder: (context) {
          return Material(
            color: Colors.transparent,
            child: NeuCard(
              width: double.infinity,
              padding: EdgeInsets.all(22),
              bevel: 5,
              curveType: CurveType.emboss,
              decoration: NeumorphicDecoration(color: Theme.of(context).scaffoldBackgroundColor, borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
              child: SafeArea(
                top: false,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      "确认操作",
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                    ),
                    SizedBox(
                      height: 12,
                    ),
                    Text(
                      action == "signal"
                          ? "是否确定要强制停止容器？所有未保存的数据将丢失！"
                          : preserveProfile
                              ? "容器 ${container['name']} 将被清除。清除后，容器中的所有数据将丢失。是否确定继续？"
                              : "容器 ${container['name']} 将被删除。删除后，容器中的所有数据将丢失。是否确定继续？",
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w400),
                    ),
                    SizedBox(
                      height: 22,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: NeuButton(
                            onPressed: () async {
                              Navigator.of(context).pop();
                              setState(() {
                                powerLoading[container['id']] = true;
                              });
                              var res = await Api.dockerPower(container['name'], action, preserveProfile: preserveProfile);
                              if (res['success']) {
                                Util.toast("请求发送成功");
                                getContainer();
                              } else {
                                Util.toast("请求发送失败，代码：${res['error']['code']}");
                              }
                              setState(() {
                                powerLoading[container['id']] = false;
                              });
                            },
                            decoration: NeumorphicDecoration(
                              color: Theme.of(context).scaffoldBackgroundColor,
                              borderRadius: BorderRadius.circular(25),
                            ),
                            bevel: 5,
                            padding: EdgeInsets.symmetric(vertical: 10),
                            child: Text(
                              "确认",
                              style: TextStyle(fontSize: 18, color: Colors.redAccent),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 16,
                        ),
                        Expanded(
                          child: NeuButton(
                            onPressed: () async {
                              Navigator.of(context).pop();
                            },
                            decoration: NeumorphicDecoration(
                              color: Theme.of(context).scaffoldBackgroundColor,
                              borderRadius: BorderRadius.circular(25),
                            ),
                            bevel: 5,
                            padding: EdgeInsets.symmetric(vertical: 10),
                            child: Text(
                              "取消",
                              style: TextStyle(fontSize: 18),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 8,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      );
    } else {
      setState(() {
        powerLoading[container['id']] = true;
      });
      var res = await Api.dockerPower(container['name'], action);
      if (res['success']) {
        Util.toast("请求发送成功");
        getContainer();
      } else {
        Util.toast("请求发送失败，代码：${res['error']['code']}");
      }
      setState(() {
        powerLoading[container['id']] = false;
      });
    }
  }

  Widget _buildContainerItem(container) {
    if (powerLoading[container['id']] == null) {
      powerLoading[container['id']] = false;
    }
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) {
              return ContainerDetail(container['name']);
            },
            settings: RouteSettings(name: "docker_container_detail")));
      },
      child: NeuCard(
        curveType: CurveType.flat,
        decoration: NeumorphicDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          borderRadius: BorderRadius.circular(20),
        ),
        bevel: 20,
        margin: EdgeInsets.only(bottom: 20),
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Text(
                              container['name'],
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                            ),
                            Spacer(),
                            container['status'] == "running"
                                ? Label("运行中", Colors.green)
                                : container['status'] == "stopped"
                                    ? Label("已停止", Colors.red)
                                    : Label(container['status'], Colors.orange),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                container['image'],
                                style: TextStyle(fontSize: 12, color: Colors.grey),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            if (container['status'] == "running")
                              Text(
                                "${container['up_time']!=null ? DateTime.fromMillisecondsSinceEpoch(container['up_time'] * 1000).timeAgo : container['up_status']}",
                                style: TextStyle(fontSize: 12, color: Colors.grey),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 20,
                  ),
                  GestureDetector(
                    onTap: () async {
                      if (powerLoading[container['id']]) {
                        return;
                      }

                      showCupertinoModalPopup(
                        context: context,
                        builder: (context) {
                          return Material(
                            color: Colors.transparent,
                            child: NeuCard(
                              width: double.infinity,
                              padding: EdgeInsets.all(22),
                              bevel: 5,
                              curveType: CurveType.emboss,
                              decoration: NeumorphicDecoration(color: Theme.of(context).scaffoldBackgroundColor, borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
                              child: SafeArea(
                                top: false,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Text(
                                      "选择操作",
                                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                                    ),
                                    SizedBox(
                                      height: 12,
                                    ),
                                    if (container['status'] == "stopped") ...[
                                      NeuButton(
                                        onPressed: () async {
                                          Navigator.of(context).pop();
                                          power(container, "start");
                                        },
                                        decoration: NeumorphicDecoration(
                                          color: Theme.of(context).scaffoldBackgroundColor,
                                          borderRadius: BorderRadius.circular(25),
                                        ),
                                        bevel: 5,
                                        padding: EdgeInsets.symmetric(vertical: 10),
                                        child: Text(
                                          "启动",
                                          style: TextStyle(fontSize: 18),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 22,
                                      ),
                                      NeuButton(
                                        onPressed: () async {
                                          Navigator.of(context).pop();
                                          power(container, "delete", preserveProfile: true);
                                        },
                                        decoration: NeumorphicDecoration(
                                          color: Theme.of(context).scaffoldBackgroundColor,
                                          borderRadius: BorderRadius.circular(25),
                                        ),
                                        bevel: 5,
                                        padding: EdgeInsets.symmetric(vertical: 10),
                                        child: Text(
                                          "清除",
                                          style: TextStyle(fontSize: 18, color: Colors.redAccent),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 22,
                                      ),
                                      NeuButton(
                                        onPressed: () async {
                                          Navigator.of(context).pop();
                                          power(container, "delete", preserveProfile: false);
                                        },
                                        decoration: NeumorphicDecoration(
                                          color: Theme.of(context).scaffoldBackgroundColor,
                                          borderRadius: BorderRadius.circular(25),
                                        ),
                                        bevel: 5,
                                        padding: EdgeInsets.symmetric(vertical: 10),
                                        child: Text(
                                          "删除",
                                          style: TextStyle(fontSize: 18, color: Colors.redAccent),
                                        ),
                                      ),
                                    ] else ...[
                                      NeuButton(
                                        onPressed: () async {
                                          Navigator.of(context).pop();
                                          power(container, "stop");
                                        },
                                        decoration: NeumorphicDecoration(
                                          color: Theme.of(context).scaffoldBackgroundColor,
                                          borderRadius: BorderRadius.circular(25),
                                        ),
                                        bevel: 5,
                                        padding: EdgeInsets.symmetric(vertical: 10),
                                        child: Text(
                                          "停止",
                                          style: TextStyle(fontSize: 18, color: Colors.redAccent),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 22,
                                      ),
                                      NeuButton(
                                        onPressed: () async {
                                          Navigator.of(context).pop();
                                          power(container, "signal");
                                        },
                                        decoration: NeumorphicDecoration(
                                          color: Theme.of(context).scaffoldBackgroundColor,
                                          borderRadius: BorderRadius.circular(25),
                                        ),
                                        bevel: 5,
                                        padding: EdgeInsets.symmetric(vertical: 10),
                                        child: Text(
                                          "强制停止",
                                          style: TextStyle(fontSize: 18, color: Colors.redAccent),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 22,
                                      ),
                                      NeuButton(
                                        onPressed: () async {
                                          Navigator.of(context).pop();
                                          power(container, "restart");
                                        },
                                        decoration: NeumorphicDecoration(
                                          color: Theme.of(context).scaffoldBackgroundColor,
                                          borderRadius: BorderRadius.circular(25),
                                        ),
                                        bevel: 5,
                                        padding: EdgeInsets.symmetric(vertical: 10),
                                        child: Text(
                                          "重新启动",
                                          style: TextStyle(fontSize: 18, color: Colors.redAccent),
                                        ),
                                      ),
                                    ],
                                    SizedBox(
                                      height: 8,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      );
                    },
                    child: NeuCard(
                      padding: EdgeInsets.all(10),
                      // margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      // padding: EdgeInsets.symmetric(vertical: 20),
                      decoration: NeumorphicDecoration(
                        color: Theme.of(context).scaffoldBackgroundColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      curveType: container['status'] == "running" ? CurveType.emboss : CurveType.flat,
                      bevel: 20,
                      child: powerLoading[container['id']]
                          ? CupertinoActivityIndicator()
                          : Image.asset(
                              "assets/icons/shutdown.png",
                              width: 20,
                            ),
                    ),
                  ),
                ],
              ),
              if (container['status'] == "running" && (containerPorts[container['name']]?.isNotEmpty ?? false))
                Padding(
                  padding: EdgeInsets.only(top: 12),
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: containerPorts[container['name']].map((port) => PopupMenuButton<String>(
                      tooltip: '打开端口 $port',
                      onSelected: (scheme) => _openContainerPort(port, scheme),
                      itemBuilder: (_) => [
                        PopupMenuItem(value: 'http', child: Text('使用 HTTP 打开')),
                        PopupMenuItem(value: 'https', child: Text('使用 HTTPS 打开')),
                      ],
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                        child: Text('端口 $port ↗', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 13)),
                      ),
                    )).toList(),
                  ),
                ),
              if (container['status'] == "running") ...[
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Text("CPU"),
                              Spacer(),
                              Text(
                                "${container['cpu'].toStringAsFixed(2)}%",
                                style: TextStyle(color: Colors.blue, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          NeuCard(
                            curveType: CurveType.flat,
                            bevel: 10,
                            decoration: NeumorphicDecoration(
                              color: Theme.of(context).scaffoldBackgroundColor,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: FAProgressBar(
                              backgroundColor: Colors.transparent,
                              changeColorValue: 90,
                              changeProgressColor: Colors.red,
                              progressColor: Colors.blue,
                              size: 20,
                              displayText: "%",
                              currentValue: (container['cpu']).ceil(),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Text("内存"),
                              Spacer(),
                              Text(
                                "${Util.formatSize(container['memory'], fixed: 0)}",
                                style: TextStyle(color: Colors.green, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          NeuCard(
                            curveType: CurveType.flat,
                            bevel: 10,
                            decoration: NeumorphicDecoration(
                              color: Theme.of(context).scaffoldBackgroundColor,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: FAProgressBar(
                              backgroundColor: Colors.transparent,
                              changeColorValue: 90,
                              changeProgressColor: Colors.red,
                              progressColor: Colors.green,
                              size: 20,
                              displayText: "%",
                              currentValue: container['memoryPercent'].ceil(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildImageItem(image) {
    return NeuCard(
      curveType: CurveType.flat,
      decoration: NeumorphicDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.circular(20),
      ),
      bevel: 20,
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Flexible(
                  child: ExtendedText(
                    "${image['repository']}:${image['tags'].join(",")}",
                    maxLines: 1,
                    overflowWidget: TextOverflowWidget(
                      position: TextOverflowPosition.middle,
                      align: TextOverflowAlign.right,
                      child: Text(
                        "…",
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                Label(Util.formatSize(image['size'], fixed: 0, format: 1000), Theme.of(context).primaryColor),
              ],
            ),
            if (image['description'] != null || image['description'] != '') ...[
              SizedBox(
                height: 10,
              ),
              Text(
                "${image['description']}",
                style: TextStyle(
                  color: Colors.grey,
                ),
              )
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: AppBackButton(context),
        title: Text(widget.title),
      ),
      body: Column(
        children: [
          NeuCard(
            width: double.infinity,
            decoration: NeumorphicDecoration(
              color: Theme.of(context).scaffoldBackgroundColor,
              borderRadius: BorderRadius.circular(20),
            ),
            margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            curveType: CurveType.flat,
            bevel: 10,
            child: TabBar(
              isScrollable: false,
              controller: _tabController,
              indicatorSize: TabBarIndicatorSize.label,
              labelColor: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
              unselectedLabelColor: Colors.grey,
              indicator: BubbleTabIndicator(
                indicatorColor: Theme.of(context).scaffoldBackgroundColor,
                shadowColor: Util.getAdjustColor(Theme.of(context).scaffoldBackgroundColor, -20),
              ),
              tabs: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                  child: Text("容器"),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                  child: Text("镜像"),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                  child: Text("注册表"),
                ),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                containerLoading
                    ? Center(
                        child: NeuCard(
                          padding: EdgeInsets.all(50),
                          curveType: CurveType.flat,
                          decoration: NeumorphicDecoration(
                            color: Theme.of(context).scaffoldBackgroundColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          bevel: 20,
                          child: CupertinoActivityIndicator(
                            radius: 14,
                          ),
                        ),
                      )
                    : ListView(
                        padding: EdgeInsets.all(20),
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: NeuCard(
                                  curveType: CurveType.flat,
                                  decoration: NeumorphicDecoration(
                                    color: Theme.of(context).scaffoldBackgroundColor,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  bevel: 20,
                                  child: Padding(
                                    padding: const EdgeInsets.all(20.0),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Image.asset(
                                              "assets/icons/cpu.png",
                                              width: 50,
                                            ),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              "CPU",
                                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        NeuCard(
                                          curveType: CurveType.flat,
                                          bevel: 10,
                                          decoration: NeumorphicDecoration(
                                            color: Theme.of(context).scaffoldBackgroundColor,
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: FAProgressBar(
                                            backgroundColor: Colors.transparent,
                                            changeColorValue: 90,
                                            changeProgressColor: Colors.red,
                                            progressColor: Colors.blue,
                                            currentValue: utilization['cpu']['user_load'] + utilization['cpu']['system_load'],
                                            displayText: '%',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 20,
                              ),
                              Expanded(
                                child: NeuCard(
                                  curveType: CurveType.flat,
                                  decoration: NeumorphicDecoration(
                                    color: Theme.of(context).scaffoldBackgroundColor,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  bevel: 20,
                                  child: Padding(
                                    padding: EdgeInsets.all(20),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Image.asset(
                                              "assets/icons/ram.png",
                                              width: 50,
                                            ),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              "内存",
                                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        NeuCard(
                                          curveType: CurveType.flat,
                                          bevel: 10,
                                          decoration: NeumorphicDecoration(
                                            color: Theme.of(context).scaffoldBackgroundColor,
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: FAProgressBar(
                                            backgroundColor: Colors.transparent,
                                            changeColorValue: 90,
                                            changeProgressColor: Colors.red,
                                            progressColor: Colors.blue,
                                            currentValue: utilization['memory']['real_usage'],
                                            displayText: '%',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          ...containers.map(_buildContainerItem).toList(),
                        ],
                      ),
                imageLoading
                    ? Center(
                        child: NeuCard(
                          padding: EdgeInsets.all(50),
                          curveType: CurveType.flat,
                          decoration: NeumorphicDecoration(
                            color: Theme.of(context).scaffoldBackgroundColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          bevel: 20,
                          child: CupertinoActivityIndicator(
                            radius: 14,
                          ),
                        ),
                      )
                    : ListView.separated(
                        padding: EdgeInsets.all(20),
                        itemBuilder: (context, i) {
                          return _buildImageItem(images[i]);
                        },
                        separatorBuilder: (context, i) {
                          return SizedBox(
                            height: 20,
                          );
                        },
                        itemCount: images.length),
                Center(
                  child: Text("开发中"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
