import 'package:dsm_helper/themes/app_theme.dart';
import 'package:dsm_helper/util/function.dart';
import 'package:dsm_helper/util/strings.dart';
import 'package:dsm_helper/widgets/expansion_container.dart';
import 'package:dsm_helper/widgets/neu_back_button.dart';
import 'package:flutter/material.dart';
import 'package:dsm_helper/util/notify_format.dart';
import 'package:neumorphic/neumorphic.dart';

class Notify extends StatefulWidget {
  final List notifies;
  Notify(this.notifies);
  @override
  _NotifyState createState() => _NotifyState();
}

class _NotifyState extends State<Notify> {
  Map<String, List> notifyGroups = {};
  List recentLogs = [];
  List fileLogs = [];
  bool loadingRecent = true;
  bool loadingFiles = true;
  bool recentFailed = false;
  bool filesFailed = false;
  @override
  void initState() {
    super.initState();
    _buildGroups();
    _loadRecentLogs();
    _loadFileLogs();
    if (Util.version == 7 && widget.notifies.any((n) => Util.notifyStrings[n['title']] == null)) {
      _loadTemplates();
    }
  }

  Future<void> _loadTemplates() async {
    try {
      final response = await Api.notifyStrings();
      if (!mounted) return;
      if (response != null && response['success'] == true && response['data'] is Map) {
        Util.notifyStrings = response['data'];
        setState(_buildGroups);
      }
    } catch (_) {
      // Keep the readable fallback when DSM templates are unavailable.
    }
  }

  void _buildGroups() {
    final groups = <String, List>{};
    for (final notify in widget.notifies) {
      final messages = notify['msg'] is List ? notify['msg'] as List : [];
      final rawTitle = notify['title']?.toString() ?? '';
      var title = fallbackNotifyTitle(notify['className'], rawTitle);
      List contents;
      if (Util.version == 7) {
        final template = Util.notifyStrings[rawTitle];
        if (template is Map && template['title'] is String && (template['title'] as String).isNotEmpty) {
          title = template['title'];
        }
        contents = messages.map((message) => formatNotifyContent(message, template is Map ? template['msg'] : null)).toList();
      } else {
        final keys = rawTitle.split(':');
        if (keys.length > 1) {
          final local = webManagerStrings[keys[0]];
          final remote = Util.strings[notify['className']];
          if (local is Map && local[keys[1]] != null) {
            title = local[keys[1]].toString();
          } else if (remote is Map && remote[keys[0]] is Map && remote[keys[0]][keys[1]] != null) {
            title = remote[keys[0]][keys[1]].toString();
          } else if (remote is Map && remote['common'] is Map && remote['common']['displayname'] != null) {
            title = remote['common']['displayname'].toString();
          }
        }
        contents = messages.map((message) => message?.toString() ?? '').toList();
      }
      final item = Map.of(notify);
      item['contents'] = contents;
      (groups[title] ??= []).add(item);
    }
    notifyGroups = groups;
  }

  Widget _buildNotifyGroup(groupName, List group) {
    return NeuCard(
      decoration: NeumorphicDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.circular(10),
      ),
      margin: EdgeInsets.only(left: 20, right: 20, top: 20),
      bevel: 10,
      curveType: CurveType.flat,
      child: ExpansionContainer(
        title: Text(
          "$groupName （${group.length}）",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          overflow: TextOverflow.ellipsis,
        ),
        children: group.map((_buildNotifyItem)).toList(),
      ),
    );
  }

  Widget _buildNotifyItem(notify) {
    return NeuCard(
      width: double.infinity,
      decoration: NeumorphicDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.circular(10),
      ),
      margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      padding: EdgeInsets.all(15),
      bevel: 10,
      curveType: CurveType.flat,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            DateTime.fromMillisecondsSinceEpoch(notify['time'] * 1000).timeAgo,
            style: TextStyle(fontSize: 14, color: Colors.grey),
          ),
          Column(
            children: (notify['contents'] as List).map((msg) {
              return Text(msg);
            }).toList(),
          ),
        ],
      ),
    );
  }

  Future<void> _loadRecentLogs() async {
    if (mounted) setState(() { loadingRecent = true; recentFailed = false; });
    try {
      final result = await Api.lastLog(0, 50);
      if (!mounted) return;
      setState(() {
        loadingRecent = false;
        recentFailed = result == null || result['success'] != true;
        if (!recentFailed) recentLogs = result['data']['logs'] is List ? result['data']['logs'] : [];
      });
    } catch (_) {
      if (mounted) setState(() { loadingRecent = false; recentFailed = true; });
    }
  }

  Future<void> _loadFileLogs() async {
    if (mounted) setState(() { loadingFiles = true; filesFailed = false; });
    try {
      final result = await Api.log(0, 50, logType: 'ftp,filestation,webdav,cifs,tftp,afp');
      if (!mounted) return;
      setState(() {
        loadingFiles = false;
        filesFailed = result == null || result['success'] != true;
        if (!filesFailed) fileLogs = result['data']['items'] is List ? result['data']['items'] : [];
      });
    } catch (_) {
      if (mounted) setState(() { loadingFiles = false; filesFailed = true; });
    }
  }

  Widget _logList(List logs, bool loading, bool failed, VoidCallback retry, {bool file = false}) {
    if (loading) return Center(child: CircularProgressIndicator());
    if (failed) return Center(child: TextButton(onPressed: retry, child: Text('加载失败，点击重试')));
    if (logs.isEmpty) return Center(child: Text('暂无日志', style: TextStyle(color: AppTheme.of(context).placeholderColor)));
    return ListView.builder(
      padding: EdgeInsets.fromLTRB(20, 16, 20, 20),
      itemCount: logs.length,
      itemBuilder: (context, index) {
        final log = logs[index];
        final text = file ? (log['descr'] ?? log['msg']) : log['msg'];
        final timestamp = file ? (log['time'] ?? log['date'] ?? '') : '${log['ldate'] ?? ''} ${log['ltime'] ?? ''}';
        return NeuCard(
          margin: EdgeInsets.only(bottom: 12), padding: EdgeInsets.all(15),
          curveType: CurveType.flat, bevel: 10,
          decoration: NeumorphicDecoration(color: Theme.of(context).scaffoldBackgroundColor, borderRadius: BorderRadius.circular(10)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (timestamp.toString().trim().isNotEmpty)
              Padding(padding: EdgeInsets.only(bottom: 8), child: Text(timestamp.toString(), style: TextStyle(fontSize: 12, color: Colors.grey))),
            Text(formatLogContent(text)),
          ]),
        );
      },
    );
  }

  Widget _messages() {
    return Column(children: [
      Expanded(child: widget.notifies.isNotEmpty
        ? ListView(children: notifyGroups.keys.map((key) => _buildNotifyGroup(key, notifyGroups[key])).toList())
        : Center(child: Text('暂无消息', style: TextStyle(color: AppTheme.of(context).placeholderColor)))),
      if (widget.notifies.isNotEmpty)
        Padding(padding: EdgeInsets.all(20), child: SizedBox(width: double.infinity, child: NeuButton(
          decoration: NeumorphicDecoration(color: Theme.of(context).scaffoldBackgroundColor, borderRadius: BorderRadius.circular(50)),
          onPressed: () async {
            final res = await Api.clearNotify();
            if (!mounted) return;
            if (res != null && res['success'] == true) {
              Util.toast('清除成功');
              Navigator.of(context).pop(true);
            } else {
              Util.toast('清除失败，请重试');
            }
          },
          child: Text('清除消息'),
        ))),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          leading: AppBackButton(context),
          title: Text('消息与日志'),
          bottom: TabBar(
            labelColor: Theme.of(context).brightness == Brightness.dark ? Colors.white : Color(0xff202633),
            unselectedLabelColor: Theme.of(context).brightness == Brightness.dark ? Color(0xffaeb6c4) : Color(0xff626b78),
            indicatorColor: Color(0xffff8900),
            tabs: [Tab(text: '消息'), Tab(text: '最新日志'), Tab(text: '文件更改')],
          ),
        ),
        body: TabBarView(children: [
          _messages(),
          _logList(recentLogs, loadingRecent, recentFailed, _loadRecentLogs),
          _logList(fileLogs, loadingFiles, filesFailed, _loadFileLogs, file: true),
        ]),
      ),
    );
  }
}
