import 'package:dsm_helper/themes/app_theme.dart';
import 'package:dsm_helper/util/function.dart';
import 'package:dsm_helper/util/strings.dart';
import 'package:dsm_helper/widgets/expansion_container.dart';
import 'package:dsm_helper/widgets/neu_back_button.dart';
import 'package:flutter/material.dart';
import 'package:dsm_helper/util/notify_format.dart';
import 'package:neumorphic/neumorphic.dart';

class Notify extends StatefulWidget {
  final List notifies;
  Notify(this.notifies);
  @override
  _NotifyState createState() => _NotifyState();
}

class _NotifyState extends State<Notify> {
  Map<String, List> notifyGroups = {};
  @override
  void initState() {
    super.initState();
    _buildGroups();
    if (Util.version == 7 && widget.notifies.any((n) => Util.notifyStrings[n['title']] == null)) {
      _loadTemplates();
    }
  }

  Future<void> _loadTemplates() async {
    try {
      final response = await Api.notifyStrings();
      if (!mounted) return;
      if (response != null && response['success'] == true && response['data'] is Map) {
        Util.notifyStrings = response['data'];
        setState(_buildGroups);
      }
    } catch (_) {
      // Keep the readable fallback when DSM templates are unavailable.
    }
  }

  void _buildGroups() {
    final groups = <String, List>{};
    for (final notify in widget.notifies) {
      final messages = notify['msg'] is List ? notify['msg'] as List : [];
      final rawTitle = notify['title']?.toString() ?? '';
      var title = fallbackNotifyTitle(notify['className'], rawTitle);
      List contents;
      if (Util.version == 7) {
        final template = Util.notifyStrings[rawTitle];
        if (template is Map && template['title'] is String && (template['title'] as String).isNotEmpty) {
          title = template['title'];
        }
        contents = messages.map((message) => formatNotifyContent(message, template is Map ? template['msg'] : null)).toList();
      } else {
        final keys = rawTitle.split(':');
        if (keys.length > 1) {
          final local = webManagerStrings[keys[0]];
          final remote = Util.strings[notify['className']];
          if (local is Map && local[keys[1]] != null) {
            title = local[keys[1]].toString();
          } else if (remote is Map && remote[keys[0]] is Map && remote[keys[0]][keys[1]] != null) {
            title = remote[keys[0]][keys[1]].toString();
          } else if (remote is Map && remote['common'] is Map && remote['common']['displayname'] != null) {
            title = remote['common']['displayname'].toString();
          }
        }
        contents = messages.map((message) => message?.toString() ?? '').toList();
      }
      final item = Map.of(notify);
      item['contents'] = contents;
      (groups[title] ??= []).add(item);
    }
    notifyGroups = groups;
  }

  Widget _buildNotifyGroup(groupName, List group) {
    return NeuCard(
      decoration: NeumorphicDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.circular(10),
      ),
      margin: EdgeInsets.only(left: 20, right: 20, top: 20),
      bevel: 10,
      curveType: CurveType.flat,
      child: ExpansionContainer(
        title: Text(
          "$groupName （${group.length}）",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          overflow: TextOverflow.ellipsis,
        ),
        showFirst: true,
        first: _buildNotifyItem(group.first),
        children: group.map((_buildNotifyItem)).toList(),
      ),
    );
  }

  Widget _buildNotifyItem(notify) {
    return NeuCard(
      width: double.infinity,
      decoration: NeumorphicDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.circular(10),
      ),
      margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      padding: EdgeInsets.all(15),
      bevel: 10,
      curveType: CurveType.flat,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            DateTime.fromMillisecondsSinceEpoch(notify['time'] * 1000).timeAgo,
            style: TextStyle(fontSize: 14, color: Colors.grey),
          ),
          Column(
            children: (notify['contents'] as List).map((msg) {
              return Text(msg);
            }).toList(),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: AppBackButton(context),
        title: Text(
          "消息",
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: widget.notifies.length > 0
                ? ListView(
                    children: notifyGroups.keys.map((key) {
                      return _buildNotifyGroup(key, notifyGroups[key]);
                    }).toList(),
                  )
                : Center(
                    child: Text(
                      "暂无消息",
                      style: TextStyle(color: AppTheme.of(context).placeholderColor),
                    ),
                  ),
          ),
          Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              children: [
                Expanded(
                  child: NeuButton(
                    decoration: NeumorphicDecoration(
                      color: Theme.of(context).scaffoldBackgroundColor,
                      borderRadius: BorderRadius.circular(50),
                    ),
                    onPressed: () async {
                      var res = await Api.clearNotify();
                      if (res['success']) {
                        Util.toast("清除成功");
                        Navigator.of(context).pop(true);
                      }
                    },
                    child: Text("全部清除"),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
