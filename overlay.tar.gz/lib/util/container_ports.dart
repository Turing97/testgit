List<int> webCandidatePorts(dynamic bindings) {
  if (bindings is! List) return [];
  final ports = <int>{};
  for (final binding in bindings) {
    if (binding is! Map) continue;
    final protocol = binding['type']?.toString().toLowerCase();
    if (protocol != null && protocol.isNotEmpty && protocol != 'tcp') continue;
    final port = int.tryParse(binding['host_port']?.toString() ?? '');
    if (port != null && port > 0 && port <= 65535) ports.add(port);
  }
  return ports.toList()..sort();
}

Uri containerWebUri(String nasAddress, int port, String scheme) {
  final base = Uri.tryParse(nasAddress ?? '');
  if (base == null || !base.hasAuthority || base.host.isEmpty || (scheme != 'http' && scheme != 'https')) return null;
  return Uri(scheme: scheme, host: base.host, port: port);
}
