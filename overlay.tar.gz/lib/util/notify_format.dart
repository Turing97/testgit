import 'dart:convert';

import 'package:html/parser.dart' as html;

const _labels = <String, String>{
  'ACCOUNT': '账号', 'BROWSER': '浏览器', 'COMPANY_NAME': '设备类型',
  'COUNTRY': '位置', 'DATE': '日期', 'DISKSTATION': '设备',
  'DS_IP': '设备 IP', 'HOSTNAME': '设备名称', 'HOST_SN': '设备序列号',
  'HTTPS_URL': 'HTTPS 地址', 'HTTP_URL': 'HTTP 地址', 'IP_ADDR': '设备 IP',
  'LINK': '链接', 'OS': '系统', 'OSNAME': '服务', 'PROTOCOL': '协议',
  'SRC_IP': '来源 IP', 'TIME': '时间',
};

Map<String, dynamic> _parameters(dynamic content) {
  if (content is Map) return Map<String, dynamic>.from(content);
  if (content is String) {
    try {
      final value = jsonDecode(content);
      if (value is Map) return Map<String, dynamic>.from(value);
    } catch (_) {}
  }
  return null;
}

String formatNotifyContent(dynamic content, dynamic template) {
  final params = _parameters(content);
  if (params == null) return content?.toString() ?? '';
  if (template is String && template.isNotEmpty) {
    var text = template;
    for (final marker in ['%LINK_BEGIN%', '%LINK_END%', '%PRE_APP_LINK%', '%POST_APP_LINK%']) {
      text = text.replaceAll(marker, '');
    }
    params.forEach((key, value) {
      text = text.replaceAll(key, value?.toString() ?? '');
    });
    text = html.parse(text).body?.text ?? text;
    if (!RegExp(r'%[A-Z][A-Z0-9_]*%').hasMatch(text)) return text.trim();
  }
  final lines = <String>[];
  params.forEach((key, value) {
    if (!key.startsWith('%') || !key.endsWith('%') || value == null || value.toString().trim().isEmpty) return;
    final name = key.substring(1, key.length - 1);
    lines.add('${_labels[name] ?? name.replaceAll('_', ' ')}：$value');
  });
  return lines.isEmpty ? '消息内容暂无法解析' : lines.join('\n');
}

String fallbackNotifyTitle(dynamic className, dynamic title) {
  final name = '${className ?? ''} ${title ?? ''}';
  if (name.contains('SecurityScan')) return '安全顾问';
  if (className is String && className.isNotEmpty && !className.startsWith('SYNO.')) return className;
  if (title is String && title.isNotEmpty && !title.contains(':') && !title.startsWith('SYNO.')) return title;
  return '系统通知';
}

String formatLogContent(dynamic content) {
  if (content == null) return '';
  dynamic parsed = content;
  if (content is String && content.trim().startsWith('{')) {
    try { parsed = jsonDecode(content); } catch (_) {}
  }
  if (parsed is Map) {
    final lines = <String>[];
    parsed.forEach((key, value) {
      if (value == null || value.toString().trim().isEmpty) return;
      final raw = key.toString();
      if (raw.startsWith('DESKTOP_NOTIFY_')) return;
      final name = raw.startsWith('%') && raw.endsWith('%') && raw.length > 2 ? raw.substring(1, raw.length - 1) : raw;
      lines.add('${_labels[name] ?? name.replaceAll('_', ' ')}：$value');
    });
    return lines.isEmpty ? content.toString() : lines.join('\n');
  }
  final text = content.toString().trim();
  final decoded = text.replaceAllMapped(RegExp(r'(?:%[0-9a-fA-F]{2})+'), (match) {
    try { return Uri.decodeComponent(match.group(0)); } catch (_) { return match.group(0); }
  });
  return _translateKnownLog(decoded);
}

String _translateKnownLog(String text) {
  final shared = RegExp(r'^User \[([^\]]+)\] from \[([^\]]+)\] via \[([^\]]+)\] accessed shared folder \[([^\]]+)\]\.$').firstMatch(text);
  if (shared != null) return '用户 [${shared[1]}] 从 [${shared[2]}] 通过 [${shared[3]}] 访问了共享文件夹 [${shared[4]}]。';
  final login = RegExp(r'^User \[([^\]]+)\] from \[([^\]]+)\] logged in successfully via \[([^\]]+)\]\.$').firstMatch(text);
  if (login != null) return '用户 [${login[1]}] 从 [${login[2]}] 通过 [${login[3]}] 登录成功。';
  final signIn = RegExp(r'^User \[([^\]]+)\] from \[([^\]]+)\] signed in to \[([^\]]+)\] successfully via \[([^\]]+)\]\.$').firstMatch(text);
  if (signIn != null) return '用户 [${signIn[1]}] 从 [${signIn[2]}] 使用 [${signIn[4]}] 成功登录 [${signIn[3]}]。';
  return text;
}
