import 'dart:convert';

import 'package:html/parser.dart' as html;

const _labels = <String, String>{
  'ACCOUNT': '账号', 'BROWSER': '浏览器', 'COMPANY_NAME': '设备类型',
  'COUNTRY': '位置', 'DATE': '日期', 'DISKSTATION': '设备',
  'DS_IP': '设备 IP', 'HOSTNAME': '设备名称', 'HOST_SN': '设备序列号',
  'HTTPS_URL': 'HTTPS 地址', 'HTTP_URL': 'HTTP 地址', 'IP_ADDR': '设备 IP',
  'LINK': '链接', 'OS': '系统', 'OSNAME': '服务', 'PROTOCOL': '协议',
  'SRC_IP': '来源 IP', 'TIME': '时间',
};

Map<String, dynamic> _parameters(dynamic content) {
  if (content is Map) return Map<String, dynamic>.from(content);
  if (content is String) {
    try {
      final value = jsonDecode(content);
      if (value is Map) return Map<String, dynamic>.from(value);
    } catch (_) {}
  }
  return null;
}

String formatNotifyContent(dynamic content, dynamic template) {
  final params = _parameters(content);
  if (params == null) return content?.toString() ?? '';
  if (template is String && template.isNotEmpty) {
    var text = template;
    for (final marker in ['%LINK_BEGIN%', '%LINK_END%', '%PRE_APP_LINK%', '%POST_APP_LINK%']) {
      text = text.replaceAll(marker, '');
    }
    params.forEach((key, value) {
      text = text.replaceAll(key, value?.toString() ?? '');
    });
    text = html.parse(text).body?.text ?? text;
    if (!RegExp(r'%[A-Z][A-Z0-9_]*%').hasMatch(text)) return text.trim();
  }
  final lines = <String>[];
  params.forEach((key, value) {
    if (!key.startsWith('%') || !key.endsWith('%') || value == null || value.toString().trim().isEmpty) return;
    final name = key.substring(1, key.length - 1);
    lines.add('${_labels[name] ?? name.replaceAll('_', ' ')}：$value');
  });
  return lines.isEmpty ? '消息内容暂无法解析' : lines.join('\n');
}

String fallbackNotifyTitle(dynamic className, dynamic title) {
  final name = '${className ?? ''} ${title ?? ''}';
  if (name.contains('SecurityScan')) return '安全顾问';
  if (className is String && className.isNotEmpty && !className.startsWith('SYNO.')) return className;
  if (title is String && title.isNotEmpty && !title.contains(':') && !title.startsWith('SYNO.')) return title;
  return '系统通知';
}
