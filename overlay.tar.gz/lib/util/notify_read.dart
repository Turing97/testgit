import 'dart:convert';
import 'package:crypto/crypto.dart';

String notifyScopeKey(String baseUrl, String account) =>
    'notify_read_${sha256.convert(utf8.encode(jsonEncode([baseUrl ?? '', account ?? ''])))}';

String notifyFingerprint(dynamic item) {
  if (item is! Map) return sha256.convert(utf8.encode(jsonEncode(item))).toString();
  return sha256.convert(utf8.encode(jsonEncode([item['time'], item['title'], item['className'], item['msg']]))).toString();
}

Set<String> parseReadNotifications(String value) {
  if (value == null || value.isEmpty) return <String>{};
  try {
    final data = jsonDecode(value);
    if (data is List) return data.whereType<String>().toSet();
  } catch (_) {}
  return <String>{};
}
