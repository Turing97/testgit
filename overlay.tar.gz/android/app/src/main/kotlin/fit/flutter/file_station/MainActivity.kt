package fit.flutter.dsm_helper

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugins.GeneratedPluginRegistrant
import org.json.JSONArray
import java.io.File
import java.util.concurrent.Executors

class MainActivity : FlutterFragmentActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var channel: MethodChannel? = null
    private val prefs by lazy { getSharedPreferences("pending_shares", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
        if (savedInstanceState == null) stageIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        stageIntent(intent)
    }

    private fun stageIntent(intent: Intent?) {
        if (intent == null) return
        val uris = when (intent.action) {
            Intent.ACTION_SEND -> listOfNotNull(intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))
            Intent.ACTION_SEND_MULTIPLE -> intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.toList() ?: emptyList()
            else -> emptyList()
        }
        if (uris.isEmpty()) return
        executor.execute {
            val pending = JSONArray(prefs.getString("paths", "[]"))
            var failed = 0
            for (uri in uris) {
                var target: File? = null
                try {
                    var name = "shared_file"
                    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
                    }
                    name = name.substringAfterLast('/').substringAfterLast('\\').replace("\u0000", "")
                    if (name.isBlank() || name == "." || name == "..") name = "shared_file"
                    val dir = File(filesDir, "pending_uploads/${java.util.UUID.randomUUID()}")
                    if (!dir.mkdirs()) throw java.io.IOException("无法创建暂存目录")
                    val output = File(dir, name)
                    target = output
                    val input = contentResolver.openInputStream(uri) ?: throw java.io.IOException("无法读取分享文件")
                    input.use { source -> output.outputStream().use { source.copyTo(it) } }
                    pending.put(output.absolutePath)
                    prefs.edit().putString("paths", pending.toString()).commit()
                } catch (_: Exception) {
                    target?.delete()
                    target?.parentFile?.delete()
                    failed++
                }
            }
            if (failed > 0) prefs.edit().putInt("failures", prefs.getInt("failures", 0) + failed).commit()
            handler.post { channel?.invokeMethod("pendingChanged", null) }
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        GeneratedPluginRegistrant.registerWith(flutterEngine)
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "dsm_helper/pending_shares")
        channel!!.setMethodCallHandler { call, result ->
            when (call.method) {
                "getPending" -> executor.execute {
                    val paths = JSONArray(prefs.getString("paths", "[]"))
                    val values = (0 until paths.length()).map { paths.getString(it) }.filter { File(it).isFile }
                    val failures = prefs.getInt("failures", 0)
                    prefs.edit().remove("failures").apply()
                    handler.post { result.success(mapOf("paths" to values, "failures" to failures)) }
                }
                "removePending" -> {
                    val removed = call.argument<List<String>>("paths") ?: emptyList()
                    executor.execute {
                        val old = JSONArray(prefs.getString("paths", "[]"))
                        val kept = JSONArray()
                        for (i in 0 until old.length()) {
                            val path = old.getString(i)
                            if (removed.contains(path)) {
                                val file = File(path)
                                file.delete()
                                file.parentFile?.delete()
                            } else kept.put(path)
                        }
                        prefs.edit().putString("paths", kept.toString()).commit()
                        handler.post { result.success(null) }
                    }
                }
                else -> result.notImplemented()
            }
        }
    }
}
