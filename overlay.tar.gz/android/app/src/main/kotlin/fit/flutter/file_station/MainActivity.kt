package fit.flutter.dsm_helper

import android.content.Intent
import android.content.ContentValues
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.MediaStore
import android.view.WindowManager
import android.webkit.MimeTypeMap
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugins.GeneratedPluginRegistrant
import org.json.JSONArray
import java.io.File
import java.util.concurrent.Executors

class MainActivity : FlutterFragmentActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var channel: MethodChannel? = null
    private val prefs by lazy { getSharedPreferences("pending_shares", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
        if (savedInstanceState == null) stageIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        stageIntent(intent)
    }

    private fun stageIntent(intent: Intent?) {
        if (intent == null) return
        val uris = when (intent.action) {
            Intent.ACTION_SEND -> listOfNotNull(intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))
            Intent.ACTION_SEND_MULTIPLE -> intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.toList() ?: emptyList()
            else -> emptyList()
        }
        if (uris.isEmpty()) return
        executor.execute {
            val pending = JSONArray(prefs.getString("paths", "[]"))
            var failed = 0
            for (uri in uris) {
                var target: File? = null
                try {
                    var name = "shared_file"
                    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
                    }
                    name = name.substringAfterLast('/').substringAfterLast('\\').replace("\u0000", "")
                    if (name.isBlank() || name == "." || name == "..") name = "shared_file"
                    val dir = File(filesDir, "pending_uploads/${java.util.UUID.randomUUID()}")
                    if (!dir.mkdirs()) throw java.io.IOException("无法创建暂存目录")
                    val output = File(dir, name)
                    target = output
                    val input = contentResolver.openInputStream(uri) ?: throw java.io.IOException("无法读取分享文件")
                    input.use { source -> output.outputStream().use { source.copyTo(it) } }
                    pending.put(output.absolutePath)
                    prefs.edit().putString("paths", pending.toString()).commit()
                } catch (_: Exception) {
                    target?.delete()
                    target?.parentFile?.delete()
                    failed++
                }
            }
            if (failed > 0) prefs.edit().putInt("failures", prefs.getInt("failures", 0) + failed).commit()
            handler.post { channel?.invokeMethod("pendingChanged", null) }
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        GeneratedPluginRegistrant.registerWith(flutterEngine)
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "dsm_helper/pending_shares")
        channel!!.setMethodCallHandler { call, result ->
            when (call.method) {
                "getPending" -> executor.execute {
                    val paths = JSONArray(prefs.getString("paths", "[]"))
                    val values = (0 until paths.length()).map { paths.getString(it) }.filter { File(it).isFile }
                    val failures = prefs.getInt("failures", 0)
                    prefs.edit().remove("failures").apply()
                    handler.post { result.success(mapOf("paths" to values, "failures" to failures)) }
                }
                "saveImage" -> {
                    val path = call.argument<String>("path")
                    val requestedName = call.argument<String>("name")
                    executor.execute {
                        var uri: Uri? = null
                        try {
                            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || path.isNullOrBlank()) {
                                throw java.io.IOException("不支持保存到相册")
                            }
                            val source = File(path)
                            if (!source.isFile || source.length() == 0L) throw java.io.IOException("图片文件为空")
                            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            BitmapFactory.decodeFile(source.absolutePath, options)
                            val mime = options.outMimeType
                            if (options.outWidth <= 0 || options.outHeight <= 0 || mime.isNullOrBlank() || !mime.startsWith("image/")) {
                                throw java.io.IOException("下载的内容不是可识别的图片")
                            }
                            var name = (requestedName ?: source.name).substringAfterLast('/').substringAfterLast('\\').replace("\u0000", "")
                            val extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
                            if (name.isBlank() || name == "." || name == "..") name = "image_${System.currentTimeMillis()}"
                            val currentExtension = name.substringAfterLast('.', "").lowercase()
                            val nameMime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(currentExtension)
                            if (extension != null && nameMime != mime) {
                                name = name.substringBeforeLast('.', name) + "." + extension
                            }
                            val values = ContentValues().apply {
                                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                                put(MediaStore.Images.Media.MIME_TYPE, mime)
                                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/群晖助手")
                                put(MediaStore.Images.Media.IS_PENDING, 1)
                            }
                            val saved = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                                ?: throw java.io.IOException("无法创建相册文件")
                            uri = saved
                            val output = contentResolver.openOutputStream(saved) ?: throw java.io.IOException("无法写入相册")
                            source.inputStream().use { input -> output.use { input.copyTo(it) } }
                            val completed = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                            if (contentResolver.update(saved, completed, null, null) < 1) throw java.io.IOException("无法完成相册保存")
                            handler.post { result.success(true) }
                        } catch (e: Exception) {
                            uri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
                            handler.post { result.error("save_image_failed", e.message ?: "保存图片失败", null) }
                        }
                    }
                }
                "removePending" -> {
                    val removed = call.argument<List<String>>("paths") ?: emptyList()
                    executor.execute {
                        val old = JSONArray(prefs.getString("paths", "[]"))
                        val kept = JSONArray()
                        for (i in 0 until old.length()) {
                            val path = old.getString(i)
                            if (removed.contains(path)) {
                                val file = File(path)
                                file.delete()
                                file.parentFile?.delete()
                            } else kept.put(path)
                        }
                        prefs.edit().putString("paths", kept.toString()).commit()
                        handler.post { result.success(null) }
                    }
                }
                else -> result.notImplemented()
            }
        }
    }
}
