package vn.hunghd.flutterdownloader

/** Range responses are accepted only for the exact previously validated entity. */
internal object ResumeSafety {
    fun validator(etag: String?, lastModified: String?): String? {
        val strong = etag?.trim()
        if (!strong.isNullOrEmpty() && !strong.startsWith("W/", ignoreCase = true)) return "E:$strong"
        val modified = lastModified?.trim()
        return if (!modified.isNullOrEmpty()) "L:$modified" else null
    }

    fun matches(stored: String?, etag: String?, lastModified: String?): Boolean {
        if (stored.isNullOrEmpty()) return false
        return when {
            stored.startsWith("E:") -> stored.substring(2) == etag?.trim()
            stored.startsWith("L:") -> stored.substring(2) == lastModified?.trim()
            else -> false
        }
    }

    fun rangeLength(header: String?, offset: Long, contentLength: Long): Long? {
        val match = Regex("bytes (\\d+)-(\\d+)/(\\d+)", RegexOption.IGNORE_CASE).matchEntire(header?.trim() ?: "") ?: return null
        val start = match.groupValues[1].toLongOrNull() ?: return null
        val end = match.groupValues[2].toLongOrNull() ?: return null
        val total = match.groupValues[3].toLongOrNull() ?: return null
        if (offset <= 0 || start != offset || end < start || total <= end || end != total - 1) return null
        val length = end - start + 1
        if (contentLength >= 0 && contentLength != length) return null
        return length
    }
}
