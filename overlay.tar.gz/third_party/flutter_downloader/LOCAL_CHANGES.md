# Local modifications

Based on flutter_downloader 1.10.2, retaining the upstream LICENSE. On 2026-11-01 the Android worker was changed to support HTTP when SSL verification is enabled, reject non-partial responses during resume, detect truncated responses and DSM JSON error responses, and guard progress calculation for unknown lengths. These changes require Android build and device verification.
